# رشدینو برای اندروید

این پروژه یک اپ اندرویدی WebView برای سایت رشدینو می‌سازد. سایت و بک‌اند همچنان روی پارس‌پک می‌مانند.

## ساخت خودکار APK در GitHub
1. این پروژه را در یک repository جدید GitHub قرار دهید.
2. از تب **Actions**، گردش‌کار **Build Roshdino APK** را اجرا کنید.
3. بعد از پایان موفق، از بخش **Artifacts** فایل `roshdino-debug-apk` را دانلود کنید.
4. ZIP مربوط به Artifact را باز کنید و `app-debug.apk` را روی گوشی نصب کنید.

## آدرس سایت
`https://app-nodejs-nhjcm.apps.teh11.abrhapaas.com/`

## یادداشت
این نسخه برای تست و نصب مستقیم (debug) است. قبل از انتشار عمومی، روی دستگاه واقعی تست شود. ساخت APK نیازمند Android SDK است؛ workflow آن را در GitHub Actions فراهم می‌کند.
